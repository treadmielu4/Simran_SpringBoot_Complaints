package com.springmvc.service;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.springmvc.model.UserDO;
import com.springmvc.repo.UserRepo;

@Service
public class UserAuthService {

	@Autowired
	private UserRepo urepo;
	
	@Autowired
	private ComplaintsService csrvc;

	public String userLogin(UserDO user, ModelMap model,HttpSession session) {

		String result = "login";

		UserDO userDB = urepo.findByLoginIdAndPassword(user.getLoginId(),user.getPassword());

		if (userDB != null) 
		{
			if(user.getPassword().equals(userDB.getPassword())
					&& user.getUserType().equals(userDB.getUserType())){
				if(EcomConstants.USER_ADMIN.equals(userDB.getUserType())) {
					result="admin";
				}else {
					session.setAttribute("userID", userDB.getUserId());
					session.setAttribute("complaintCount", csrvc.getCount(userDB.getUserId()));
					result="customer";
				}
				
			}
		} 
		else 
		{
			//System.out.println("User not exist");
			// session.setAttribute("invalid", "Invalid User");
			 model.addAttribute("invalid", "Invalid Login Id or Password!");
			
		}
		//
		
		return result;

	}
	
	public String userRegistration(UserDO user) {
		
		String result="success";
		user.setUserType("C");
		user.setIsActive('Y'); 
		
		UserDO userDB=urepo.findByLoginId(user.getLoginId());
		if(null!= userDB) {
			
			result="failed";
		}
		else {
			
			urepo.save(user);
		}
		return result;
		
	}

}
