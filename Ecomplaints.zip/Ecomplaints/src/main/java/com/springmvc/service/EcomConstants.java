package com.springmvc.service;

public class EcomConstants {
	
	public static final String PRIORITY_LOW = "LOW";
	public static final String PRIORITY_MEDIUM = "MEDIUM";
	public static final String PRIORITY_HIGH = "HIGH";
	public static final String USER_ADMIN = "A";
	public static final String USER_CUSTOMER = "C";
	public static final String STATUS_OPEN = "Open";
	public static final String STATUS_CLOSED = "Closed";



}
