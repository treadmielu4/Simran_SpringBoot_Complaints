package com.springmvc.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springmvc.model.ComplaintsDO;
import com.springmvc.repo.ComplaintsRepo;

@Service
public class ComplaintsService {
	
	@Autowired
	ComplaintsRepo crepo;
	
	public ComplaintsDO createUserComplaint(ComplaintsDO cdo) {
		
		cdo.setCreatedDt(new Date());
		cdo.setPriority(EcomConstants.PRIORITY_MEDIUM);
		cdo.setStatus(EcomConstants.STATUS_OPEN);
		
		crepo.save(cdo);
		
		return cdo;
	}
	
	public ComplaintsDO getUserComplaintDO(Integer cid, Integer userID) {
		
		return crepo.findByCidAndCreatedBy(cid, userID);
		
	}
	
	public ComplaintsDO getComplaintDO(ComplaintsDO cdo) {
		return crepo.findByCid(cdo.getCid());
		
	}
	
	public Integer getCount(Integer cid){
		
		Integer count = new Integer(0);
	//	List<ComplaintsDO> data = crepo.findByCreatedBy(cid);
	//	if(null != data) {
		//	count= data.size();
		//}
				
		return crepo.countByCreatedBy(cid);
	}
	
	public ComplaintsDO updateComplaint(ComplaintsDO cdo) {
		
		ComplaintsDO cdo1 = crepo.findByCid(cdo.getCid());
		cdo1.setStatus(cdo.getStatus());
		cdo1.setPriority(cdo.getPriority());
		
		crepo.save(cdo1);
		return cdo1;
	}
	
	
	public List<ComplaintsDO> getComplaintsList(){
		//return crepo.findAll();
		return crepo.findByOrderByCreatedDtDesc();
		
	}


	

}
