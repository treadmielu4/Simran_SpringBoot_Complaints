package com.springmvc.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springmvc.model.ComplaintsDO;

@Repository
public interface ComplaintsRepo extends JpaRepository<ComplaintsDO , Integer>{

	public ComplaintsDO findByCid(Integer cid);
	public ComplaintsDO findByCidAndCreatedBy(Integer cid,Integer userId);
	public List<ComplaintsDO> findAll();
	public List<ComplaintsDO> findByCreatedBy(Integer cid);
	public List<ComplaintsDO> findByOrderByCreatedDtDesc();
	public Integer countByCreatedBy(Integer cid);

}
