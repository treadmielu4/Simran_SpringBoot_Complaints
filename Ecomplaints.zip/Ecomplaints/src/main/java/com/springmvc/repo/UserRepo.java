package com.springmvc.repo;

import org.springframework.stereotype.Repository;

import com.springmvc.model.UserDO;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface UserRepo extends JpaRepository<UserDO , Integer> {
	
	//public UserDO findByUserName(String userName);

	//public UserDO findByUserNameAndPassword(String userName, String password);
	public UserDO findByLoginId(String loginId);
	public UserDO findByLoginIdAndPassword(String userName, String password);

}
