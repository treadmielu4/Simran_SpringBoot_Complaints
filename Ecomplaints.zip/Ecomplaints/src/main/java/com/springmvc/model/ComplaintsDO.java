package com.springmvc.model;


import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity(name="COM_COMPLAINT_DTLS")
public class ComplaintsDO {
	
	@Id
	@SequenceGenerator(name="complaint_seq", initialValue=1000, allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="complaint_seq")
	private Integer cid;
	private String heading;
	
	@Column(name="cdescription")
	private String desc;
	
	private Date createdDt;
	@Column(name="cstatus")
	private String status;
	
	private String priority;
	private Integer createdBy;
	
	
	
	public String getHeading() {
		return heading;
	}
	public void setHeading(String heading) {
		this.heading = heading;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public Date getCreatedDt() {
		return createdDt;
	}
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public Integer getCid() {
		return cid;
	}
	public void setCid(Integer cid) {
		this.cid = cid;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	@Override
	public String toString() {
		return "ComplaintsDO [cid=" + cid + ", heading=" + heading + ", desc=" + desc + ", createdDt=" + createdDt
				+ ", status=" + status + ", priority=" + priority + ", createdBy=" + createdBy + "]";
	}
	
	

}
