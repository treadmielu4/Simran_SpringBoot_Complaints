package com.springmvc.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springmvc.model.ComplaintsDO;
import com.springmvc.model.UserDO;
import com.springmvc.repo.ComplaintsRepo;
import com.springmvc.repo.UserRepo;
import com.springmvc.service.ComplaintsService;
import com.springmvc.service.EcomConstants;
import com.springmvc.service.UserAuthService;

@Controller
public class EcomplaintsController {

	@Autowired
	private UserRepo urepo;
	
	@Autowired
	private UserAuthService usrvc;
	
	@Autowired
	private ComplaintsService csrvc;
	 
	@Autowired
	private ComplaintsRepo crepo;
	
	@RequestMapping("/easybank")
	public String welcomepage() {
		
		return "login";
	}
	
	
	@GetMapping("complainDetails/{cid}")
	public String showComplaintDetails(@PathVariable("cid") Integer cid,
			HttpSession session) {
		ComplaintsDO cdo=new ComplaintsDO();
		cdo.setCid(cid);
		cdo=csrvc.getComplaintDO(cdo);
		session.setAttribute("msghead", cdo.getHeading());
		session.setAttribute("msgcid", cdo.getCid());
		session.setAttribute("msgpriority", cdo.getPriority());
		session.setAttribute("msgdescription", cdo.getDesc());
		session.setAttribute("msgstatus", cdo.getStatus());
		
		return "complaintDetails";
	}
	
	
	
	@PostMapping("/updateComplain" )
	public String updateComplain(@RequestParam("cid") Integer cid,
			@RequestParam("status") String status,
			@RequestParam("priority") String priority,
			HttpSession session,
			ModelMap model){
		
		ComplaintsDO cdo=new ComplaintsDO();
		cdo.setCid(cid);
		cdo.setStatus(status);
		cdo.setPriority(priority);
		csrvc.updateComplaint(cdo);
		
		 model.addAttribute("record", "Record updated!!");
		 model.addAttribute("complaint", csrvc.getComplaintsList());
		return "admin";
	}
	
	@PostMapping("/login" )
	public String userLogin(@RequestParam("login_Id") String loginId,
			@RequestParam("password") String password,
			@RequestParam("type") String type,
			ModelMap model,HttpSession session) {
		
		String result="invaild";
		UserDO user = new UserDO();
		user.setLoginId(loginId);
		user.setUserType(type);
		user.setPassword(password);
		
		result = usrvc.userLogin(user,model,session);
		
		if("admin".equals(result)) {
			model.addAttribute("complaint", csrvc.getComplaintsList());
		}
		
		return result;
	}
	@PostMapping("/newComplaint")
	public String createUserComplaint(@RequestParam("title") String title, 
			@RequestParam("description") String description,
			HttpSession session,ModelMap model) {
		ComplaintsDO cdo= new ComplaintsDO();
		cdo.setHeading(title);
		cdo.setDesc(description);
		cdo.setCreatedBy(new Integer(session.getAttribute("userID").toString()));
		cdo = csrvc.createUserComplaint(cdo);
		session.setAttribute("complaintCount", csrvc.getCount(cdo.getCreatedBy()));
		model.addAttribute("message", "New Complaint Raised!! Complaint ID : " + cdo.getCid() );
		
		return "customer";
	}
	
	@PostMapping("/seeStatus")
	public String seeStatus(@RequestParam("cid") Integer cid, HttpSession session,ModelMap model) {
		ComplaintsDO cdo=new ComplaintsDO();
		
		Integer userId = new Integer(session.getAttribute("userID").toString());
		
		cdo=csrvc.getUserComplaintDO( cid,  userId);
		
		if(cdo!=null) {
		//session.setAttribute("msghead", cdo.getHeading());
		//session.setAttribute("msgdescription", cdo.getDesc());
		//session.setAttribute("msgstatus", cdo.getStatus());
			model.addAttribute("msgshead", cdo.getHeading());
			model.addAttribute("msgsdescription", cdo.getDesc());
			model.addAttribute("msgsstatus", cdo.getStatus());
		return "checkStatus";
		}
		else {
			model.addAttribute("notFound", "Complaint not found!");
			return "checkStatus";
		}
	}
	
	@RequestMapping("/customer")
	public String customerpage(HttpSession session) {
		Integer uid=new Integer(session.getAttribute("userID").toString());
		session.setAttribute("complaintCount", csrvc.getCount(uid));
		session.removeAttribute("message");
		return "customer";
	}
	@RequestMapping("/checkStatus")
	public String statuspage(HttpSession session,ModelMap model) {
		//session.removeAttribute("message");
		model.remove("msgshead");
		model.remove("msgsdescription");
		model.remove("msgsstatus");
		return "checkStatus";
	}
	
	@RequestMapping("/logout")
	public String loginpage(HttpSession session) {
		session.removeAttribute("invalid");
		
		return "login";
	}
	
	
	@RequestMapping("back")
	public String goToAdmin(ModelMap model) {
	
		model.addAttribute("complaint", csrvc.getComplaintsList());
		return "admin";
	}
	
	@RequestMapping("/customerRegister")
	public String goToCustomerRegister() {
		return "register";
	}
	
	@RequestMapping("/registration")
	public String userRegistration(@RequestParam("user_Name") String userName, 
			@RequestParam("password") String password,
			@RequestParam("email") String email,
			@RequestParam("loginId") String loginId,ModelMap model) {
		UserDO user =  new UserDO();
		user.setUserName(userName);
		user.setPassword(password);
		user.setEmail(email);
		user.setLoginId(loginId);
		
		
		String result= usrvc.userRegistration(user);
		
		if("success".equals(result)) {
			model.addAttribute("msg", "Congratulations " +user.getUserName() +"!!! Your account has been created.");
			
			return "login";
		}
		else {
			model.addAttribute("msg", "Login Id already exists, Please choose another one");
			return "register";

		}
	}
}
